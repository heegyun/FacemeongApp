package com.seolab.facemeongapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class SplashActivity extends FragmentActivity {

    DatabaseReference mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        Handler x = new Handler();
        x.postDelayed(new IntroHandler(), 3000);


    }

    class IntroHandler implements Runnable{
        @Override
        public void run() {
            mDatabase = FirebaseDatabase.getInstance().getReference();

            mDatabase.child("users").child("1").addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    // Get Post object and use the values to update the UI
                    if(dataSnapshot.getValue(User.class) != null){
                        User post = dataSnapshot.getValue(User.class);
                        Log.w("FireBaseData", "getData" + post.toString());
                        Intent it = new Intent(getApplicationContext(), MainActivity.class);
                        startActivity(it);
                    }else{
                        Toast.makeText(SplashActivity.this, "정보 없음...", Toast.LENGTH_SHORT).show();
                        Intent it = new Intent(getApplicationContext(), PreRegisterActivity.class);
                        startActivity(it);
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    // Getting Post failed, log a message
                    Log.w("FireBaseData", "loadPost:onCancelled", databaseError.toException());
                }
            });
        }
    }

}