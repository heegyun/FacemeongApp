package com.seolab.facemeongapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class PreRegisterActivity extends AppCompatActivity {

    TextView reg_title,reg_title2,reg_txt1,reg_txt2;
    Button btn_reg;
    DatabaseReference mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pre_register);

        Handler x = new Handler();
        x.postDelayed(new PreRegisterActivity.IntroHandler(), 1);
        init(); // findViewById 초기화
    }


    public void init() {

        reg_title = findViewById(R.id.reg_title);
        reg_title2 = findViewById(R.id.reg_title2);
        reg_txt1 = findViewById(R.id.reg_txt1);
        reg_txt2 =  findViewById(R.id.reg_txt2);
        btn_reg = findViewById(R.id.btn_reg);


    }

    public  void petReg(View view){
        Intent intent = new Intent(getApplicationContext(), RegisterActivity.class);
        startActivity(intent);
        finish();

    }

    class IntroHandler implements Runnable{
        @Override
        public void run() {
            mDatabase = FirebaseDatabase.getInstance().getReference();

            mDatabase.child("users").child("1").addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    // Get Post object and use the values to update the UI

                    if(dataSnapshot.getValue(User.class) != null){
                        User post = dataSnapshot.getValue(User.class);
                        Log.w("FireBaseData", "getData" + post.toString());
                        Intent it = new Intent(getApplicationContext(), MainActivity.class);
                        startActivity(it);
                        finish();
                    }else{
                        Toast.makeText(PreRegisterActivity.this, "정보 없음...", Toast.LENGTH_SHORT).show();
                        /*Intent it = new Intent(getApplicationContext(), PreRegisterActivity.class);
                        startActivity(it);*/
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    // Getting Post failed, log a message
                    Log.w("FireBaseData", "loadPost:onCancelled", databaseError.toException());
                }
            });
        }
    }
}