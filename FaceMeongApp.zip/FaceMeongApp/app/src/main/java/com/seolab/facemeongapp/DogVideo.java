package com.seolab.facemeongapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class DogVideo extends AppCompatActivity {

    DatabaseReference mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dog_video);

        TextView dog_name_tv = (TextView) findViewById(R.id.tv_receivename3);

        //VideoView frontVideo = (VideoView) findViewById(R.id.front_video);
        VideoView backVideo = (VideoView) findViewById(R.id.back_video);

        //Uri uri_front = Uri.parse("android.resource://" + getPackageName() + "/raw/dog_front");
        Uri uri_back = Uri.parse("android.resource://"+getPackageName()+"/raw/dog");

        /*frontVideo.setVideoURI(uri_front);
        frontVideo.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mp) {
                mp.start();
                mp.setLooping(true);
            }
        });*/

        backVideo.setVideoURI(uri_back);
        backVideo.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mp) {
                mp.start();
                mp.setLooping(true);
            }
        });

        mDatabase = FirebaseDatabase.getInstance().getReference();
        readUser();
        mDatabase.child("users").child("1").child("userName").addValueEventListener(new ValueEventListener(){
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String value = dataSnapshot.getValue().toString();
                dog_name_tv.setText(value);
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error){

            }
        });

        ImageButton dog_cancle_bt = (ImageButton) findViewById(R.id.cancle_button);
        dog_cancle_bt.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view){
                Intent intent = new Intent(getApplication(), MainActivity.class);
                startActivity(intent);
            }
        });
    }

    private void readUser(){
        mDatabase.child("users").child("1").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                // Get Post object and use the values to update the UI
                if(dataSnapshot.getValue(User.class) != null){
                    User post = dataSnapshot.getValue(User.class);
                    Log.w("FireBaseData", "getData" + post.toString());
                } else {
                    Toast.makeText(DogVideo.this, "데이터 없음...", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // Getting Post failed, log a message
                Log.w("FireBaseData", "loadPost:onCancelled", databaseError.toException());
            }
        });
    }
/*
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_dog_video, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        int id = item.getItemId();

        if(id == R.id.action_reg_main) {
            Intent it = new Intent(this, MainActivity.class);
            startActivity(it);
            finish();
            return true;
        }else if(id==R.id.action_dog_menu){
            Intent it = new Intent(this, DogMenu.class);
            startActivity(it);
            finish();
            return true;
        }else if(id==R.id.action_dog_cursta){
            Intent it = new Intent(this, DogCursta.class);
            startActivity(it);
            finish();
            return true;
        }else if(id==R.id.action_dog_status){
            Intent it = new Intent(this, DogStatus.class);
            startActivity(it);
            finish();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }*/
}