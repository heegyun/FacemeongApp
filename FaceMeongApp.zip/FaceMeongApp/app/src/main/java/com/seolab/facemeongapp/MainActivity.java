package com.seolab.facemeongapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import de.hdodenhof.circleimageview.CircleImageView;

public class MainActivity extends AppCompatActivity {

    DatabaseReference mDatabase;

    CircleImageView dog_video_bt;
    ImageView backgroundImage, pet_state_img;
    TextView pet_name, pet_state_text1, pet_age, pet_breed, pet_happy_text, pet_title, pet_name2;



    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
/*
        Handler x = new Handler();
        x.postDelayed(new MainActivity.IntroHandler(), 3000);
*/
        TextView dog_name_tv = (TextView) findViewById(R.id.pet_name);

        mDatabase = FirebaseDatabase.getInstance().getReference();
        readUser();

        // 이름 불러오기
        mDatabase.child("users").child("1").child("userName").addValueEventListener(new ValueEventListener(){
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String value = dataSnapshot.getValue().toString();
                dog_name_tv.setText(value);
                pet_name2.setText(value);
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error){

            }
        });

        // 종류 불러오기
        mDatabase.child("users").child("1").child("petBreed").addValueEventListener(new ValueEventListener(){
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String value = dataSnapshot.getValue().toString();
                pet_breed.setText(value);
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error){

            }
        });

        // 나이 불러오기
        mDatabase.child("users").child("1").child("petAge").addValueEventListener(new ValueEventListener(){
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String value = dataSnapshot.getValue().toString();
                pet_age.setText(value + "살");
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error){

            }
        });

        dog_video_bt = (CircleImageView) findViewById(R.id.pet_picture);

        FirebaseStorage storage = FirebaseStorage.getInstance();
        StorageReference storageReference = storage.getReference();
        StorageReference pathReference = storageReference.child("photo");
        if(pathReference==null){
            Toast.makeText(MainActivity.this,"저장소에 사진이 없습니다.", Toast.LENGTH_SHORT).show();
        }else{
            StorageReference submitProfile = storageReference.child("photo/1.png");
            submitProfile.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                @Override
                public void onSuccess(Uri uri) {
                    Glide.with(MainActivity.this).load(uri).into(dog_video_bt);
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {

                }
            });
        }
        dog_video_bt.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view){
                Intent intent = new Intent(getApplication(), DogVideo.class);
                startActivity(intent);
            }
        });

        init(); // findViewById 초기화
    }

    /*class IntroHandler implements Runnable{
        @Override
        public void run() {
            mDatabase = FirebaseDatabase.getInstance().getReference();

            mDatabase.child("users").child("1").addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    // Get Post object and use the values to update the UI
                    if(dataSnapshot.getValue(User.class) != null){
                        User post = dataSnapshot.getValue(User.class);
                        Log.w("FireBaseData", "getData" + post.toString());
                        Intent it = new Intent(getApplicationContext(), MainActivity.class);
                        startActivity(it);
                    }else{
                        Toast.makeText(MainActivity.this, "정보 없음...", Toast.LENGTH_SHORT).show();
                        Intent it = new Intent(getApplicationContext(), PreRegisterActivity.class);
                        startActivity(it);
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    // Getting Post failed, log a message
                    Log.w("FireBaseData", "loadPost:onCancelled", databaseError.toException());
                }
            });
        }
    }*/

    private void readUser(){
        mDatabase.child("users").child("1").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                // Get Post object and use the values to update the UI
                if(dataSnapshot.getValue(User.class) != null){
                    User post = dataSnapshot.getValue(User.class);
                    Log.w("FireBaseData", "getData" + post.toString());
                } else {
                    Toast.makeText(MainActivity.this, "데이터 없음...", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // Getting Post failed, log a message
                Log.w("FireBaseData", "loadPost:onCancelled", databaseError.toException());
            }
        });
    }

    public void init() {

        backgroundImage = findViewById(R.id.background);
        pet_state_text1 = findViewById(R.id.pet_state_text1);
        pet_title = findViewById(R.id.pet_title);
        pet_state_img = findViewById(R.id.pet_state_img);
        pet_happy_text = findViewById(R.id.pet_happy_text);
        pet_name = findViewById(R.id.pet_name);
        pet_age = findViewById(R.id.pet_age);
        pet_breed = findViewById(R.id.pet_breed);
        pet_name2 = findViewById(R.id.pet_name2);

    }


    // 등록 화면으로 이동 추가
    public void sendRegisterActivity(View view) {
        Intent intent = new Intent(getApplicationContext(), RegisterActivity.class);
        startActivity(intent);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        int id = item.getItemId();

        if(id == R.id.action_dog_add) {
            Intent it = new Intent(this, RegisterActivity.class);
            startActivity(it);
            finish();
            return true;
        }else if(id==R.id.action_dog_edit){
            Intent it = new Intent(this, DogEdit.class);
            startActivity(it);
            finish();
            return true;
        }else if(id==R.id.action_dog_status){
            Intent it = new Intent(this, DogStatus.class);
            startActivity(it);
            finish();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


}