package com.seolab.facemeongapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.renderscript.Sampler;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.InputStream;
import java.util.HashMap;

public class RegisterActivity extends AppCompatActivity {

    private final int GALLERY_CODE = 10;
    ImageView photo;


    private DatabaseReference mDatabase;
    ImageView imageView;
    FirebaseStorage storage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        imageView=(ImageView)findViewById(R.id.imageView);
        ImageButton reg_next_bt = (ImageButton) findViewById(R.id.next_button);
        //ImageButton img_bt = (ImageButton) findViewById(R.id.imageButton);
        EditText reg_sendname_edt = (EditText) findViewById(R.id.dog_name);
        TextView reg_petage_tv = (TextView) findViewById(R.id.tv_age);
        SeekBar reg_petage_sb = (SeekBar) findViewById(R.id.sb_age);
        Spinner reg_petbreed_sp = (Spinner) findViewById(R.id.spinner3);
        Spinner reg_petsize_sp = (Spinner) findViewById(R.id.sp_size);
        findViewById(R.id.imageView).setOnClickListener(onClickListener);
        photo=(ImageView)findViewById(R.id.imageView);

        reg_petage_sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                reg_petage_tv.setText(String.format("%d",reg_petage_sb.getProgress()));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        mDatabase = FirebaseDatabase.getInstance().getReference();
        readUser();

        reg_next_bt.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view){
                Intent it = new Intent(getApplication(), MainActivity.class);
                String getUserName = reg_sendname_edt.getText().toString();
                String getPetAge = reg_petage_tv.getText().toString();
                String getPetBreed = reg_petbreed_sp.getSelectedItem().toString();
                Long getPetBreedId = reg_petbreed_sp.getSelectedItemId();
                String getPetSize = reg_petsize_sp.getSelectedItem().toString();
                Long getPetSizeId = reg_petsize_sp.getSelectedItemId();

                HashMap result = new HashMap<>();
                result.put("name", getUserName);
                result.put("age", getPetAge);
                result.put("breed", getPetBreed);
                result.put("size", getPetSize);
                result.put("sizeid", getPetSizeId);
                result.put("breedid", getPetBreedId);

                writeNewUser("1", getUserName, getPetAge, getPetBreed, getPetSize, getPetSizeId, getPetBreedId);
                startActivity(it);
            }
        });

        storage=FirebaseStorage.getInstance();

    }

    View.OnClickListener onClickListener = new View.OnClickListener(){
        @Override
        public void onClick(View v){
            switch (v.getId()){
                case R.id.imageView:
                    loadAlbum();
                    break;
            }
        }
    };

    private void loadAlbum(){
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType(MediaStore.Images.Media.CONTENT_TYPE);
        startActivityForResult(intent, GALLERY_CODE);
    }

    @Override
    protected void onActivityResult(int requestCode, final int resultCode, final Intent data){
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == GALLERY_CODE){
            Uri file = data.getData();
            StorageReference storageRef = storage.getReference();
            StorageReference riversRef = storageRef.child("photo/1.png");
            UploadTask uploadTask = riversRef.putFile(file);

            try{
                InputStream in = getContentResolver().openInputStream(data.getData());
                Bitmap img = BitmapFactory.decodeStream(in);
                in.close();
                photo.setImageBitmap(img);
            }catch(Exception e){
                e.printStackTrace();
            }

            uploadTask.addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Toast.makeText(RegisterActivity.this, "사진이 정상적으로 업로드 되지 않았습니다.", Toast.LENGTH_SHORT).show();
                }
            });
            uploadTask.addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                    Toast.makeText(RegisterActivity.this, "사진이 정상적으로 업로드 되었습니다.", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }






    private void writeNewUser(String userId, String name, String age, String breed, String size, Long sizeid, Long breedid) {
        User user = new User(name, age, breed, size, sizeid, breedid);


        mDatabase.child("users").child(userId).setValue(user)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        // Write was successful!
                        Toast.makeText(RegisterActivity.this, "저장을 완료했습니다.", Toast.LENGTH_SHORT).show();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        // Write failed
                        Toast.makeText(RegisterActivity.this, "저장을 실패했습니다.", Toast.LENGTH_SHORT).show();
                    }
                });

    }

    private void readUser(){
        mDatabase.child("users").child("1").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                // Get Post object and use the values to update the UI
                if(dataSnapshot.getValue(User.class) != null){
                    User post = dataSnapshot.getValue(User.class);
                    Log.w("FireBaseData", "getData" + post.toString());
                } else {
                    Toast.makeText(RegisterActivity.this, "데이터 없음...", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // Getting Post failed, log a message
                Log.w("FireBaseData", "loadPost:onCancelled", databaseError.toException());
            }
        });
    }
/*
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_reg, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        int id = item.getItemId();

        if(id == R.id.action_main) {
            Intent it = new Intent(this, MainActivity.class);
            startActivity(it);
            finish();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }*/
}