package com.seolab.facemeongapp;

import com.google.firebase.database.IgnoreExtraProperties;

@IgnoreExtraProperties
public class User {

    public String userName;
    public String petAge;
    public String petBreed;
    public String petSize;
    public Long petSizeId;
    public Long petBreedId;

    public User() {
        // Default constructor required for calls to DataSnapshot.getValue(User.class)
    }

    public User(String userName){
        this.userName = userName;
    }

    public User(String petAge, String petBreed, String petSize, Long petSizeId, Long petBreedId)
    {
        this.petAge = petAge;
        this.petBreed = petBreed;
        this.petSize = petSize;
        this.petSizeId = petSizeId;
        this.petBreedId = petBreedId;
    }
    public User(String userName, String petAge, String petBreed, String petSize, Long petSizeId, Long petBreedId)
    {
        this.userName = userName;
        this.petAge = petAge;
        this.petBreed = petBreed;
        this.petSize = petSize;
        this.petSizeId = petSizeId;
        this.petBreedId = petBreedId;
    }

    public String getUserName() {
        return userName;
    }

    public String getPetAge(){
        return petAge;
    }

    public String getPetBreed(){
        return petBreed;
    }

    public String getPetSize(){
        return petSize;
    }

    public Long getPetSizeId(){
        return petSizeId;
    }

    public Long getPetBreedId(){
        return petBreedId;
    }

    public void setUserName(String userName, String petAge, String petBreed, String petSize, Long petSizeId, Long petBreedId)
    {
        this.userName = userName;
        this.petAge = petAge;
        this.petBreed = petBreed;
        this.petSize = petSize;
        this.petSizeId = petSizeId;
        this.petBreedId = petBreedId;
    }

    @Override
    public String toString() {
        return "User{" +
                "userName='" + userName + '\'' +
                '}';
    }
}
